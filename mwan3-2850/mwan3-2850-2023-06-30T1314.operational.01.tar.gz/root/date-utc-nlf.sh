#!/bin/sh
echo -n `date -u +"%Y-%m-%dT%H:%M:%S%z"`
