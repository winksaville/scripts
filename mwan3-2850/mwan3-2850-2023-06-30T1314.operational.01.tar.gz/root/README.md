Important note:

 I've modifed the backup configuration using
[System -> Backup/Flash Firmware] and then
clicking the [Configuration] tab. There I added
"/root/". The result is that etc/systemupgrade.conf
contains:
```
$ cat etc/sysupgrade.conf
7:/root/
```

And these files are used by mwan3.user

mwan3.process.sh Invoked by mwan3.user so the processing done by
                 mwan3.user could be invoked with `nohup`. Turns
                 out that didn't work well, see mwan3.user.

date-utc-nlf.sh  A script that is used by mwan3.user and lives in
                 /root it prints the date in utc without a linefeed

mail-wink.sh     A script that is used by mwan3.user and lives in
                 /root it sends an email to wink@saville.com and an
                 sms to 8312342134

mwan3.user.log   Log data from mwan3.user and the code it calls
